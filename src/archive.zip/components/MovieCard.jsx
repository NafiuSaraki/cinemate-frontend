import React from "react";

const MovieCard = ({ movie }) => {
  return (
    <div className="bg-white rounded-xl overflow-hidden shadow-md hover:shadow-lg transition w-48">
      <img
        src={movie.poster}
        alt={movie.title}
        className="w-full h-64 object-cover"
      />
      <div className="p-3">
        <h3 className="font-semibold text-lg text-gray-800 truncate">{movie.title}</h3>
        <p className="text-sm text-gray-500">⭐ {movie.rating}</p>
      </div>
    </div>
  );
};

export default MovieCard;