// src/App.js
import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import Navbar from "./components/Navbar"
import Home from "./pages/HomePage";
import Trending from "./pages/Trending";
import Login from "./pages/Login";
import Register from "./pages/Register";
import MovieDetails from "./pages/MovieDetails"; // 🆕
import Bookmarks from "./pages/Bookmarks"; // 🆕
import { ThemeProvider } from "./context/ThemeContext";

function App() {
  return (
    <ThemeProvider>
    <Router>
      <Navbar />
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/trending" element={<Trending />} />
        <Route path="/login" element={<Login />} />
        <Route path="/register" element={<Register />} />
        <Route path="/movie/:id" element={<MovieDetails />} /> {/* 🆕 */}
          <Route path="/trending" element={<Trending />} />
      <Route path="/movie/:id" element={<MovieDetails />} />
      <Route path="/bookmarks" element={<Bookmarks />} />
      </Routes>
    </Router>
    </ThemeProvider>
  );
}

export default App;