// src/pages/Login.jsx
import React from 'react';

const Login = () => {
  return (
    <div className="bg-black min-h-screen flex items-center justify-center">
      <form className="bg-gray-800 p-6 rounded-lg shadow-lg w-full max-w-md">
        <h2 className="text-2xl font-semibold text-white mb-4">🔐 Login to CinMate</h2>
        <input type="email" placeholder="Email" className="w-full mb-3 p-2 rounded bg-gray-700 text-white" />
        <input type="password" placeholder="Password" className="w-full mb-4 p-2 rounded bg-gray-700 text-white" />
        <button className="w-full bg-red-600 py-2 rounded hover:bg-red-700 transition text-white">Login</button>
      </form>
    </div>
  );
};

export default Login;